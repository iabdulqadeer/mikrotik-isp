
<?php
  $u = auth()->user();
  $C = $currency ?? ($u?->display_currency ?? config('currency.default.code','USD'));
?>



<?php $__env->startSection('content'); ?>
  
  <div class="mb-6">
    <div class="text-[15px] font-medium">
      <?php echo e($greeting); ?>, <?php echo e($u->name ?? 'there'); ?>! 👋
    </div>
    <div class="text-[13px] text-gray-500">
      <?php echo e(\Illuminate\Support\Carbon::now($tz)->format('D, M j · g:i A')); ?> (<?php echo e($tz); ?>)
    </div>
  </div>
  
  
  <?php $u = auth()->user(); ?>
  <?php if($u->isOnTrial()): ?>
    <div class="mb-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
      <div class="flex items-center justify-between">
        <div>
          <div class="font-semibold text-amber-900">Free Trial Active</div>
          <div class="text-sm text-amber-800">
            Ends on <strong><?php echo e($u->trial_ends_at->timezone($tz)->format('M d, Y H:i')); ?></strong>
            (<?php echo e(max($u->trialDaysLeft(), 0)); ?> day<?php echo e($u->trialDaysLeft() === 1 ? '' : 's'); ?> left).
          </div>
        </div>
        <a href="<?php echo e(route('subscriptions.index')); ?>"
           class="inline-flex px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-sm hover:bg-indigo-700">
          Upgrade now
        </a>
      </div>
    </div>
  <?php elseif(!$u->hasActiveSubscription() && $u->hasExpiredTrial()): ?>
    <div class="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
      <div class="flex items-center justify-between">
        <div>
          <div class="font-semibold text-red-900">Access Restricted</div>
          <div class="text-sm text-red-800">
            Your free trial has ended. Please upgrade to continue using premium features.
          </div>
        </div>
        <a href="<?php echo e(route('subscriptions.index')); ?>"
           class="inline-flex px-3 py-1.5 rounded-lg bg-red-600 text-white text-sm hover:bg-red-700">
          Choose a plan
        </a>
      </div>
    </div>
  <?php elseif($u->canStartTrial()): ?>
    <div class="rounded-xl flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border border-sky-200 bg-sky-50 px-4 py-3 mb-3">
      <div>
        <div class="font-semibold text-sky-900">Start your 3-day free trial</div>
        <div class="text-sm text-sky-800">Try all premium features for 3 days. No card required to start.</div>
      </div>
      <form method="POST" action="<?php echo e(route('trial.start')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit"
          class="inline-flex px-3 py-1.5 rounded-lg bg-amber-500 text-white text-sm hover:bg-amber-600 w-full sm:w-auto justify-center">
          Start Free Trial
        </button>
      </form>
    </div>
  <?php endif; ?>

  
  <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
    <div class="bg-white rounded-2xl border shadow-sm p-4 md:p-5">
      <div class="text-[12px] text-gray-600">Amount this month</div>
      <div class="mt-1 flex items-center justify-between">
        <div class="text-[26px] leading-7 font-semibold"><?php echo e($C); ?> <?php echo e(number_format($stats['amount_this_month'] ?? 0,2)); ?></div>
        <div class="w-10 h-10 rounded-xl grid place-items-center text-white bg-gradient-to-br from-orange-500 to-orange-600">
          <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 1v22M5 6h9a3 3 0 0 1 0 6H8a3 3 0 0 0 0 6h11"/></svg>
        </div>
      </div>
      <div class="mt-1 text-[12px] text-gray-500">Total earned this month</div>
    </div>

    <div class="bg-white rounded-2xl border shadow-sm p-4 md:p-5">
      <div class="text-[12px] text-gray-600">SMS Balance</div>
      <div class="mt-1 flex items-center justify-between">
        <div class="text-[26px] leading-7 font-semibold"><?php echo e($C); ?> <?php echo e(number_format($stats['sms_balance'] ?? 0,2)); ?></div>
        <div class="w-10 h-10 rounded-xl grid place-items-center text-indigo-600 bg-indigo-50">
          <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/></svg>
        </div>
      </div>
      <div class="mt-1 text-[12px] text-gray-500">Your SMS balance</div>
    </div>

    <div class="bg-white rounded-2xl border shadow-sm p-4 md:p-5">
      <div class="text-[12px] text-gray-600">Total Clients</div>
      <div class="mt-1 flex items-center justify-between">
        <div class="text-[26px] leading-7 font-semibold"><?php echo e(number_format($stats['total_clients'] ?? 0)); ?></div>
        <div class="w-10 h-10 rounded-xl grid place-items-center text-violet-600 bg-violet-50">
          <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
        </div>
      </div>
      <div class="mt-1 text-[12px] text-gray-500">Number of clients (<?php echo e($stats['subscribed_clients'] ?? 0); ?> subscribed)</div>
    </div>

    <div class="bg-white rounded-2xl border shadow-sm p-4 md:p-5">
      <div class="text-[12px] text-gray-600">Commission Earned</div>
      <div class="mt-1 flex items-center justify-between">
        <div class="text-[26px] leading-7 font-semibold"><?php echo e($C); ?> <?php echo e(number_format($stats['commission'] ?? 0,2)); ?></div>
        <div class="w-10 h-10 rounded-xl grid place-items-center text-amber-600 bg-amber-50">
          <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 3v18h18"/><rect x="7" y="12" width="3" height="6"/><rect x="12" y="9" width="3" height="9"/><rect x="17" y="5" width="3" height="13"/></svg>
        </div>
      </div>
      <div class="mt-1 text-[12px] text-gray-500"><?php echo e((int)($commissionRate*100)); ?>% commission this month</div>
    </div>
  </div>

  
  <div class="mt-4 flex items-center gap-3 text-[12px] text-gray-500">
    <div class="ml-auto">
      Account Expiry
      <span class="font-medium">
        <?php echo e(($stats['expires_at'] ?? null) ? $stats['expires_at']->format('M d, Y') : '—'); ?>

      </span>
    </div>
    <button class="px-3 py-1.5 rounded-lg border bg-white hover:bg-gray-50">Filters</button>
  </div>

  
  <div class="mt-4 grid lg:grid-cols-2 gap-4">
    <?php if (isset($component)) { $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-chart','data' => ['title' => 'Payments','filter' => 'This year','canvasId' => 'revExpChart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Payments','filter' => 'This year','canvasId' => 'revExpChart']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $attributes = $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $component = $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-chart','data' => ['title' => 'Active Users','filter' => 'This week','canvasId' => 'activeUsersChart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Active Users','filter' => 'This week','canvasId' => 'activeUsersChart']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $attributes = $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $component = $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
  </div>

  
  <div class="mt-4 grid lg:grid-cols-2 gap-4">
    <?php if (isset($component)) { $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-chart','data' => ['title' => 'Customer retention rate (6 months)','filter' => 'This year','canvasId' => 'retentionChart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Customer retention rate (6 months)','filter' => 'This year','canvasId' => 'retentionChart']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $attributes = $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $component = $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-chart','data' => ['title' => 'Data Usage','filter' => 'This week','canvasId' => 'dataUsageChart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Data Usage','filter' => 'This week','canvasId' => 'dataUsageChart']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $attributes = $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $component = $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
  </div>

  
  <div class="mt-4 grid lg:grid-cols-2 gap-4">
    <?php if (isset($component)) { $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-chart','data' => ['title' => 'Package Utilization','filter' => '','canvasId' => 'pkgDonutChart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Package Utilization','filter' => '','canvasId' => 'pkgDonutChart']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $attributes = $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $component = $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-chart','data' => ['title' => 'Revenue Forecast (3 months)','filter' => '','canvasId' => 'forecastChart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Revenue Forecast (3 months)','filter' => '','canvasId' => 'forecastChart']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $attributes = $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $component = $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
  </div>

  
  <div class="mt-4 grid lg:grid-cols-2 gap-4">
    <?php if (isset($component)) { $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-chart','data' => ['title' => 'Sent SMS','filter' => 'This week','canvasId' => 'smsWeekChart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Sent SMS','filter' => 'This week','canvasId' => 'smsWeekChart']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $attributes = $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $component = $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card-chart','data' => ['title' => 'User Registrations','filter' => 'This week','canvasId' => 'regsWeekChart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'User Registrations','filter' => 'This week','canvasId' => 'regsWeekChart']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $attributes = $__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__attributesOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6)): ?>
<?php $component = $__componentOriginal69d3d1001eda62f5c6a44b265f9487b6; ?>
<?php unset($__componentOriginal69d3d1001eda62f5c6a44b265f9487b6); ?>
<?php endif; ?>
  </div>

  
  <div class="mt-4 grid lg:grid-cols-2 gap-4">
    <div class="bg-white rounded-2xl border shadow-sm p-4">
      <div class="mb-3 font-medium">Most Active Users</div>
      <?php if(($topUsers ?? collect())->isEmpty()): ?>
        <div class="text-gray-500 text-sm">No active users yet.</div>
      <?php else: ?>
        <ul class="space-y-2">
          <?php $__currentLoopData = $topUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="flex items-center justify-between text-sm">
              <span class="truncate"><?php echo e($row->username ?? 'Unknown'); ?></span>
              <span class="text-gray-500"><?php echo e($row->sessions); ?> sessions</span>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php endif; ?>
    </div>

    <div class="bg-white rounded-2xl border shadow-sm p-4">
      <div class="mb-3 font-medium">Package Performance Comparison</div>
      <div class="overflow-x-auto">
        <table class="w-full text-[13px]">
          <thead>
            <tr class="text-left text-gray-500">
              <th class="py-2">Package Name</th>
              <th class="py-2">Price</th>
              <th class="py-2">Active Users</th>
              <th class="py-2">Monthly Revenue</th>
              <th class="py-2">Avg. Data Usage</th>
              <th class="py-2">ARPU</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = ($pkgPerf ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr class="border-t">
                <td class="py-2"><?php echo e($r['name']); ?></td>
                <td class="py-2"><?php echo e($C); ?> <?php echo e(number_format($r['price'],2)); ?></td>
                <td class="py-2"><?php echo e($r['active_users']); ?></td>
                <td class="py-2"><?php echo e($C); ?> <?php echo e(number_format($r['monthly_revenue'],2)); ?></td>
                <td class="py-2"><?php echo e(number_format($r['avg_data'],2)); ?> MB</td>
                <td class="py-2"><?php echo e($C); ?> <?php echo e(number_format($r['arpu'],2)); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr><td colspan="6" class="py-4 text-gray-500">No data available.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
  <script>
    const fmt = new Intl.NumberFormat(undefined, {maximumFractionDigits:2});

    const rev = <?php echo json_encode($charts['revenue_expenses']['revenue'] ?? [], 15, 512) ?>;
    const exp = <?php echo json_encode($charts['revenue_expenses']['expenses'] ?? [], 15, 512) ?>;
    new Chart(document.getElementById('revExpChart'), {
      type: 'line',
      data: { labels: <?php echo json_encode($charts['revenue_expenses']['labels'] ?? [], 15, 512) ?>,
        datasets: [
          { label:'Revenue', data: rev,   tension:.35, fill:false },
          { label:'Expenses',data: exp,   tension:.35, fill:false }
        ]
      },
      options: { responsive:true, plugins:{ legend:{ display:true }}, scales:{ y:{ beginAtZero:true } } }
    });

    new Chart(document.getElementById('activeUsersChart'), {
      type: 'line',
      data: { labels: <?php echo json_encode($charts['active_users_week']['labels'] ?? [], 15, 512) ?>,
        datasets: [{ label:'Active', data:<?php echo json_encode($charts['active_users_week']['active'] ?? [], 15, 512) ?>, tension:.35, fill:false }]
      },
      options:{ scales:{ y:{ beginAtZero:true, ticks:{ precision:0 } } } }
    });

    new Chart(document.getElementById('retentionChart'), {
      type: 'line',
      data: {
        labels: <?php echo json_encode($charts['retention']['labels'] ?? [], 15, 512) ?>,
        datasets: [
          { label:'New',       data:<?php echo json_encode($charts['retention']['new'] ?? [], 15, 512) ?>, tension:.35, fill:false },
          { label:'Returning', data:<?php echo json_encode($charts['retention']['returning'] ?? [], 15, 512) ?>, tension:.35, fill:false },
          { label:'Churn',     data:<?php echo json_encode($charts['retention']['churn'] ?? [], 15, 512) ?>, tension:.35, fill:false }
        ]
      },
      options:{ scales:{ y:{ beginAtZero:true } } }
    });

    new Chart(document.getElementById('dataUsageChart'), {
      type: 'line',
      data: {
        labels: <?php echo json_encode($charts['data_usage']['labels'] ?? [], 15, 512) ?>,
        datasets: [
          { label:'Download (MB)', data:<?php echo json_encode($charts['data_usage']['download'] ?? [], 15, 512) ?>, tension:.35, fill:false },
          { label:'Upload (MB)',   data:<?php echo json_encode($charts['data_usage']['upload'] ?? [], 15, 512) ?>,   tension:.35, fill:false }
        ]
      },
      options:{ scales:{ y:{ beginAtZero:true } } }
    });

    new Chart(document.getElementById('pkgDonutChart'), {
      type: 'doughnut',
      data: { labels:<?php echo json_encode($charts['packages']['labels'] ?? [], 15, 512) ?>,
        datasets:[{ data:<?php echo json_encode($charts['packages']['values'] ?? [], 15, 512) ?> }]
      },
      options:{ cutout:'65%' }
    });

    new Chart(document.getElementById('forecastChart'), {
      type: 'line',
      data: {
        labels: <?php echo json_encode($charts['forecast']['labels'] ?? [], 15, 512) ?>,
        datasets: [
          { label:'Historical Revenue', data:<?php echo json_encode($charts['forecast']['hist'] ?? [], 15, 512) ?>, tension:.35, fill:false },
          { label:'Forecast', data:<?php echo json_encode($charts['forecast']['pred'] ?? [], 15, 512) ?>, tension:.35, fill:false },
          { label:'Upper Confidence', data:<?php echo json_encode($charts['forecast']['high'] ?? [], 15, 512) ?>, tension:.35, borderDash:[6,6], fill:false },
          { label:'Lower Confidence', data:<?php echo json_encode($charts['forecast']['low'] ?? [], 15, 512) ?>,  tension:.35, borderDash:[6,6], fill:false },
        ]
      },
      options:{ scales:{ y:{ beginAtZero:true } } }
    });

    new Chart(document.getElementById('smsWeekChart'), {
      type: 'bar',
      data: { labels:<?php echo json_encode($charts['sms_week']['labels'] ?? [], 15, 512) ?>,
        datasets:[{ label:'Messages', data:<?php echo json_encode($charts['sms_week']['values'] ?? [], 15, 512) ?> }]
      },
      options:{ scales:{ y:{ beginAtZero:true, ticks:{ precision:0 } } } }
    });

    new Chart(document.getElementById('regsWeekChart'), {
      type: 'bar',
      data: { labels:<?php echo json_encode($charts['registrations']['labels'] ?? [], 15, 512) ?>,
        datasets:[{ label:'Registrations', data:<?php echo json_encode($charts['registrations']['values'] ?? [], 15, 512) ?> }]
      },
      options:{ scales:{ y:{ beginAtZero:true, ticks:{ precision:0 } } } }
    });
  </script>

  
  <div class="mt-4 bg-white rounded-2xl border shadow-sm">
    <div class="px-4 py-3 border-b font-medium">Mobile Money Integration Status</div>
    <div class="p-4 grid md:grid-cols-2 lg:grid-cols-3 gap-3">
      <?php
        $rows = [
          ['MTN MoMo','Uganda, Rwanda, Ghana','Ready','bg-yellow-100 text-yellow-700 border-yellow-200'],
          ['Airtel Money','Kenya, Uganda','Ready','bg-yellow-100 text-yellow-700 border-yellow-200'],
          ['M-Pesa','Kenya, Tanzania','Ready','bg-yellow-100 text-yellow-700 border-yellow-200'],
          ['Tigo Pesa','Tanzania','Ready','bg-yellow-100 text-yellow-700 border-yellow-200'],
          ['Telebirr','Ethiopia','Testing','bg-amber-50 text-amber-700 border-amber-200'],
          ['NilePay','South Sudan','Pending','bg-gray-50 text-gray-600 border-gray-200'],
        ];
      ?>
      <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name,$desc,$label,$badge]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="border rounded-2xl p-4 flex items-start gap-3">
          <div class="w-9 h-9 rounded-xl bg-gray-100 grid place-items-center font-semibold text-[11px]">
            <?php echo e(strtoupper(substr($name,0,3))); ?>

          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2">
              <div class="font-medium truncate"><?php echo e($name); ?></div>
              <span class="px-2 py-0.5 text-[11px] rounded-full border <?php echo e($badge); ?>"><?php echo e($label); ?></span>
            </div>
            <div class="text-[12px] text-gray-500 truncate"><?php echo e($desc); ?></div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php if (! $__env->hasRenderedOnce('b7361c1d-3d16-43a8-a2fa-6e92bec5b7a8')): $__env->markAsRenderedOnce('b7361c1d-3d16-43a8-a2fa-6e92bec5b7a8'); ?>
  <?php $__env->startPush('components'); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', ['title' => 'Dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\mikrotik-isp\resources\views/dashboard.blade.php ENDPATH**/ ?>