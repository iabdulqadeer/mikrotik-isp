<div class="mt-5"></div>
<?php if(session('ok')): ?>
  <div class="mb-3 rounded-xl border bg-emerald-50 text-emerald-800 px-4 py-3"><?php echo e(session('ok')); ?></div>
<?php endif; ?>
<?php if(session('err')): ?>
  <div class="mb-3 rounded-xl border bg-rose-50 text-rose-700 px-4 py-3"><?php echo e(session('err')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
  <div class="mb-3 rounded-xl border bg-rose-50 text-rose-700 px-4 py-3"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<?php if(session('status')): ?>
  <div class="mb-3 rounded-xl border bg-emerald-50 text-emerald-800 px-4 py-3"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="mb-3 rounded-xl border bg-rose-50 text-rose-700 px-4 py-3">
    <div class="font-semibold mb-1">Please fix the following:</div>
    <ul class="list-disc ml-5">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php /**PATH D:\wamp64\www\mikrotik-isp\resources\views/partials/flash.blade.php ENDPATH**/ ?>