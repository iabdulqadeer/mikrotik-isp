<div class="flex justify-center mb-6">
    <a href="{{ url('/') }}">
        <img src="{{ asset('logo_transparent.png') }}" alt="App Logo" class="h-12 w-auto">
    </a>
</div>
