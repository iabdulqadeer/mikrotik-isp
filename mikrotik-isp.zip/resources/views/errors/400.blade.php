﻿@php
  $code = 400;
  $title = 'Bad Request';
  $description = 'The request could not be understood by the server. Please check your input and try again.';
@endphp
@include('errors.page')
