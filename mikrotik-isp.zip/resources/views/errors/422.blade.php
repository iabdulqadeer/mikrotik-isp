﻿@php
  $code = 422;
  $title = 'Validation Error';
  $description = 'We couldnt process your request due to validation errors.';
@endphp
@include('errors.page')
