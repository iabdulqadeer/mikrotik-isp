﻿@php
  $code = 408;
  $title = 'Request Timeout';
  $description = 'The server timed out waiting for the request. Please try again.';
@endphp
@include('errors.page')
