﻿@php
  $code = 500;
  $title = 'Server Error';
  $description = 'Something went wrong on our end. Our team has been notified.';
@endphp
@include('errors.page')
