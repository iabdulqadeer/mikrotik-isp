﻿@php
  $code = 419;
  $title = 'Page Expired';
  $description = 'Your session has expired. Please refresh the page and try again.';
@endphp
@include('errors.page')
