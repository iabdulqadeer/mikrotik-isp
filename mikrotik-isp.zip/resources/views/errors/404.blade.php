﻿@php
  $code = 404;
  $title = 'Page not found';
  $description = 'We cant find the page youre looking for.';
@endphp
@include('errors.page')
