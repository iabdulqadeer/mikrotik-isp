﻿@php
  $code = 403;
  $title = 'Forbidden';
  $description = 'You dont have permission to view this resource.';
@endphp
@include('errors.page')
