﻿@php
  $code = 401;
  $title = 'Unauthorized';
  $description = 'You need to sign in to access this page.';
@endphp
@include('errors.page')
