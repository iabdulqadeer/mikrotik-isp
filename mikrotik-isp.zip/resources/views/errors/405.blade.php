﻿@php
  $code = 405;
  $title = 'Method Not Allowed';
  $description = 'The HTTP method is not allowed for this route.';
@endphp
@include('errors.page')
