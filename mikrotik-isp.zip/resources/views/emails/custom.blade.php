@component('mail::message')
{!! $htmlMessage !!}
@endcomponent
