<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class InternetProfile extends Model
{
    protected $fillable = ['name']; // extend as needed
}